MAP01 - Por Pedro Knabach Andrade

1 - O que é DOOM?
	DOOM é um jogo de tiro lançado pra MS-DOS, e que depois,
	foi lançado pra Playstation, SNES, ect.
	Anos depois, foi relançado pra PC (atuais), Nintendo Switch, 
	XBOX One, PS4 e PS5, ect.

2 - Como iniciar a fase?
	Passo 1: extraia o arquivo ZIP, e, depois, mova os arquivos
		 da pasta "A fase em si" para a pasta "Crispy DOOM".
	Passo 2: mova o arquivo "DOOM2.wad" da pasta "DOOM 2" para a pasta
		 "Crispy DOOM".
	Passo 3: inicie o Chocolate DOOM e, se NÃO entrar na fase,
		 procure um toturial de "Como iniciar WADs costumizados no Chocolate DOOM".

3 - Quais são os controles?
	CTRL: atirar;
	ALT + ← ou →: andar para a esquerda e/ou para a direita;
	← ou →: virar a câmera;
	↑ ou ↓: andar pra frente e/ou para trás;
	Números de 1 a 7: trocar as armas;
	shift: correr (funciona só junto com as setas);
	TAB: mapa.